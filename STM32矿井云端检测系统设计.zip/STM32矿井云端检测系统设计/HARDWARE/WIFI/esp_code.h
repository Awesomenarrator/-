#ifndef _ESP_CODE_H_
#define _ESP_CODE_H_

#include "stm32f10x.h"
#include "stdio.h"

#define WIFI_ID "main"
#define WIFI_PASSWORD "88888888"

#define SER_ADDR "bj-2-mqtt.iot-api.com"
extern char u2_rev_buf[512];

void usart2_init(void);
void ESP8266_IO_Config(void);
char  esp8266_senddata(char *at_cmd,char *ret1,char *ret2,uint32_t tim);
void esp8266_check(void);
void esp8266_set_mode(void);
void usart2_sendstr(char *str);

#endif
