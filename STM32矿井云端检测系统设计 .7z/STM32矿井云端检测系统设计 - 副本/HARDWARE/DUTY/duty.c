#include "duty.h"
#include <string.h>
 
// ˽�к궨�� 
#define DUST_SENSOR_HEADER       0xA5 
#define UART3_RX_BUF_SIZE        64 
#define DUST_DATA_PACKAGE_LEN    4 
 
// ˽��ȫ�ֱ��� 
static uint8_t uart3_rx_buf[UART3_RX_BUF_SIZE];
static volatile uint8_t rx_len = 0;
static volatile uint8_t data_ready = 0;
 
// USART3��ʼ�� 
void USART3_DustSensor_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    USART_InitTypeDef USART_InitStruct;
    NVIC_InitTypeDef NVIC_InitStruct;
 
    // 1. ʱ��ʹ�� 
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
 
    // 2. GPIO���� 
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10; // TX 
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStruct);
 
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_11; // RX 
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOB, &GPIO_InitStruct);
 
    // 3. USART�������� 
    USART_InitStruct.USART_BaudRate = 9600;
    USART_InitStruct.USART_WordLength = USART_WordLength_8b;
    USART_InitStruct.USART_StopBits = USART_StopBits_1;
    USART_InitStruct.USART_Parity = USART_Parity_No;
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART3, &USART_InitStruct);
 
    // 4. �ж����� 
    USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);
    USART_ITConfig(USART3, USART_IT_IDLE, ENABLE);
    
    NVIC_InitStruct.NVIC_IRQChannel = USART3_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);
 
    // 5. ʹ��USART3 
    USART_Cmd(USART3, ENABLE);
}
 
// USART3�жϷ����� 
void USART3_IRQHandler(void)
{
    // �����ж� 
    if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET) {
        if(rx_len < UART3_RX_BUF_SIZE) {
            uart3_rx_buf[rx_len++] = USART_ReceiveData(USART3);
        } else {
            USART_ReceiveData(USART3); // ����������� 
        }
    }
    
    // �����жϣ�֡������
    if(USART_GetFlagStatus(USART3, USART_FLAG_IDLE) != RESET) {
        USART_ReceiveData(USART3); // ���IDLE��־ 
        data_ready = 1;            // �������ݾ�����־ 
    }
}
 
// ��ȡ�۳�Ũ�ȣ���λ����g/m3��
DustStatus GetDustConcentration(uint16_t* pConcentration)
{
		uint8_t i = 0;
		DustStatus status = DUST_DATA_ERROR;
		uint32_t timeout = 2000000; // ����ϵͳtick�Ĵ��Գ�ʱ 
    // ������� 
    if(pConcentration == NULL) {
        return DUST_DATA_ERROR;
    }
 
    // �ȴ����ݽ��գ�2�볬ʱ�� 
    while(!data_ready && timeout--);
    
    if(!timeout) {
        rx_len = 0;
        return DUST_DATA_TIMEOUT;
    }
 
    // ���ݽ��� 
    
    for(i=0; i<=rx_len-DUST_DATA_PACKAGE_LEN; i++) 
		{
        if(uart3_rx_buf[i] == DUST_SENSOR_HEADER) {
            // ����У��ͣ�����ͷ + DATAH + DATAL��
            uint8_t checksum = (uart3_rx_buf[i] + 
                               uart3_rx_buf[i+1] + 
                               uart3_rx_buf[i+2]) & 0x7F;
            if(checksum == uart3_rx_buf[i+3]) {
                // ���14λŨ��ֵ 
                *pConcentration = ((uart3_rx_buf[i+1] & 0x7F) << 7) | 
                                  (uart3_rx_buf[i+2] & 0x7F);
                status = DUST_DATA_OK;
                break;
            }
        }
    }
 
    // ״̬���� 
    rx_len = 0;
    data_ready = 0;
    
    return status;
}