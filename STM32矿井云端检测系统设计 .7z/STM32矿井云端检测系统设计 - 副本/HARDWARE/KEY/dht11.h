#ifndef  __DHT11_H__
#define  __DHT11_H__
 
#include "sys.h"
#include "stm32f10x.h"
 
#define DHT11_PORT      GPIOC
#define DHT11_CLK       RCC_APB2Periph_GPIOC
#define DHT11_TRIG      GPIO_Pin_4
#define DHT11           GPIO_ReadInputDataBit(DHT11_PORT,DHT11_TRIG)
 
#define DHT11_HIGH      PCout(4)
#define DHT11_LOW       PCin(4)
 
void DHT11_GPIO_OUT(void);
void DHT11_GPIO_IN(void);
uint8_t DHT_Read_Byte(void);
uint8_t DHT_Read(void);
 
#endif