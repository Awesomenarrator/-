#ifndef _ESP8266_H_
#define _ESP8266_H_

#include "sys.h"
#include "usart.h"	  
#include "pwm.h"

#define ESP_USART        USART2 
#define ESP_BAUDRATE     115200 
#define ESP_RX_BUF_SIZE  512 
#define ESP_TIMEOUT_MS   5000 

typedef enum {
    AT_OK,
    AT_ERROR,
    AT_TIMEOUT 
} AT_Status;


void Usart_wifi_config(u32 bound);
int ESP8266_ConnectServer(const char* ip, uint16_t port);
int ESP8266_ConnectWiFi(const char* ssid, const char* pwd);
AT_Status ESP8266_SendCommand(const char* cmd, char* response, uint16_t timeout);
int ESP8266_SendData(const char* data, uint16_t len);
int ESP8266_ConnectMQTT(const char* server, const char* port, const char* client_id, const char* user, const char* pwd);

#endif
