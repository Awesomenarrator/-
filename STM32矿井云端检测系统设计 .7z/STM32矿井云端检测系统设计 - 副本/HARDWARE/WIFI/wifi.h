#ifndef __WIFI_H__
#define __WIFI_H__

#include "stm32f10x.h"
//#include "gpio.h"

#define WIFI_RESET    GPIOA->ODR &=  ~(1 << 5)
#define WIFI_UNRESET  GPIOA->ODR |=   (1 << 5)

#define WIFI_DISABLE GPIOA->ODR &=  ~(1 << 4)
#define WIFI_ENABLE  GPIOA->ODR |=   (1 << 4)

extern u8 wifiRecvOver;
extern u8 recvCnt;
extern u8 wifiRecvBuf[100];

/* USER CODE BEGIN Private defines */
typedef enum{
	STA,
  AP,
  STA_AP  
} ENUM_Net_ModeTypeDef;
 
typedef enum{
	 enumTCP,
	 enumUDP,
} ENUM_NetPro_TypeDef;
	
 
typedef enum{
	Multiple_ID_0 = 0,
	Multiple_ID_1 = 1,
	Multiple_ID_2 = 2,
	Multiple_ID_3 = 3,
	Multiple_ID_4 = 4,
	Single_ID_0 = 5,
} ENUM_ID_NO_TypeDef;
extern	char connect_report[179];
extern u8 MQTT_SEND_RealtimeData[2048];



/* USER CODE END Private defines */
 
void MX_USART1_UART_Init(void);
void MX_USART3_UART_Init(void);
 
_Bool WIFI_Init(void);

/* USER CODE BEGIN Prototypes */

_Bool testAT( void );
_Bool ESP8266_DHCP_CUR (void);
_Bool ESP8266_Net_Mode_Choose ( ENUM_Net_ModeTypeDef enumMode );
_Bool ESP8266_JoinAP ( char * pSSID, char * pPassWord );
_Bool ESP8266_Enable_MultipleId ( FunctionalState enumEnUnvarnishTx );
_Bool ESP8266_Link_Server ( ENUM_NetPro_TypeDef enumE, char * ip, char * ComNum, ENUM_ID_NO_TypeDef id);
_Bool ESP8266_UnvarnishSend ( void );
int Tcp_RW(char *sendbuf,char *recvbuf);
_Bool TCP_Init();
void UART_Init();
void USART2_Send(u8* data,int len);
_Bool cmdAT(char *cmdData,char *expReturn1,char *expReturn2,int len);
int ConnectMqtt(char *ClientID,char *Username,char *Password);
int MqttSubscribeTopic(char *topic,u8 qos,u8 whether);
int MqttPublishData(char * topic, char * message,int DataLen);
/* USER CODE END Prototypes */

#endif

