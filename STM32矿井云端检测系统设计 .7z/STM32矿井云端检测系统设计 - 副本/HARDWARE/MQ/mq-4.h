#ifndef _MQ_4_H_
#define _MQ_4_H_

#include "stm32f10x.h"

void ADC1_A0_Init(void);

void D0_PC0_Init(void);
uint8_t D0_ReadStatus(void);
int Read_MQ4_Voltage(void);

#endif