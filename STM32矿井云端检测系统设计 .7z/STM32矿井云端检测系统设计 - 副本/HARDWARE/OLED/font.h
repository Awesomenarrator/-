#ifndef _FONT_H_
#define _FONT_H_

#include "stm32f10x.h"
extern const u8 Aciss_8X16[];

extern u8 pic[];
extern u8 chain[];

#endif

