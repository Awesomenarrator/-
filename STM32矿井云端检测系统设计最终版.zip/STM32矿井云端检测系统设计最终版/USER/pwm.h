#ifndef _PWM_H_
#define _PWM_H_


#include "stm32f10x.h"

void PWM_Init(void);
void Duoji_on(void);
void DuoJi_config(void);
void Duoji_off(void);
void DuoJi_start(u8 direction);

#endif
