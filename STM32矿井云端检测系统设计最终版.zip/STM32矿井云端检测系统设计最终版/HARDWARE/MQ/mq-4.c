#include "mq-4.h"
#include"led.h"
#include "pwm.h"

void ADC1_A0_Init(void)
{
    // 修正后的ADC初始化（PA0通道）
    GPIO_InitTypeDef GPIO_InitStructure;
    ADC_InitTypeDef ADC_InitStructure;
 
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_ADC1, ENABLE);//使能GPIOA和ADC1时钟
    
    // PA0配置 
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
 
    // ADC参数 
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;   //
    ADC_InitStructure.ADC_ScanConvMode = DISABLE; // 单通道禁用扫描 
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE; // 连续转换 
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;//禁止外部触发 
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;//右对齐 
    ADC_InitStructure.ADC_NbrOfChannel = 1;//单通道 
    ADC_Init(ADC1, &ADC_InitStructure);//ADC初始化
    
    // 校准 
    ADC_Cmd(ADC1, ENABLE);//使能ADC
    ADC_ResetCalibration(ADC1);//复位校准寄存器
    while(ADC_GetResetCalibrationStatus(ADC1)); //等待校准结束
    ADC_StartCalibration(ADC1); //开始校准
    while(ADC_GetCalibrationStatus(ADC1));//等待校准结束
    
    // 通道配置 
    ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_239Cycles5);//配置ADC1通道0，采样时间239.5 cycles
    ADC_SoftwareStartConvCmd(ADC1, ENABLE); // 启动连续转换 
}
void D0_PC0_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);//使能GPIOC时钟
    //GPIOC
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //上拉输入
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
}

uint8_t D0_ReadStatus(void) 
{
    return GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_0); // 返回0表示报警 
}
int Read_MQ4_Voltage(void)
{
    ADC_SoftwareStartConvCmd(ADC1, ENABLE); 
    // 等待转换完成 
    while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC)); //等待转换结束 
    ADC_ClearFlag(ADC1, ADC_FLAG_EOC); 
    // 返回转换结果 
    return ADC_GetConversionValue(ADC1);
}
